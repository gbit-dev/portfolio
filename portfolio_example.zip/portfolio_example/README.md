# Portfólio (exemplo)
Este é um exemplo simples de portfólio para te ajudar a começar.

## Como usar este exemplo
1. Abre a pasta `portfolio_example` no teu computador.
2. Clica em `index.html` para ver o site localmente (no navegador).
3. Para publicar no GitHub Pages:
   - Cria um repositório no GitHub (ex: `portfolio`) e faz upload destes ficheiros.
   - Ou faz `git init`, `git add .`, `git commit -m "inicial"` e `git remote add origin <URL>` seguido de `git push -u origin main`.
   - Vai a Settings → Pages → Branch `main` → Save para ativar GitHub Pages.
4. Substitui "Teu Nome" e "teu-email@example.com" pelo teu nome e email.
5. Podes duplicar a pasta `projects/top10-musicas` para adicionar mais projetos.

## Dicas rápidas
- Mantém commits pequenos e com mensagens claras.
- Escreve um README para cada projeto explicando o que fizeste.
- Se não quiseres usar Git local, podes carregar os ficheiros através da interface web do GitHub.
