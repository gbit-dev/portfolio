# Top 10 — Músicas (exemplo)
Este pequeno projeto mostra uma tabela com 10 entradas fictícias.

## Como ver
1. Abre `index.html` no navegador para ver a tabela.
2. Se publicares no GitHub Pages, a página ficará disponível online.

## Sugestões de melhoria
- Adicionar imagens na coluna "Foto" (pasta assets/fotos).
- Adicionar um filtro com JavaScript para procurar pelo nome do artista.
- Tornar a tabela responsiva para telemóveis.
